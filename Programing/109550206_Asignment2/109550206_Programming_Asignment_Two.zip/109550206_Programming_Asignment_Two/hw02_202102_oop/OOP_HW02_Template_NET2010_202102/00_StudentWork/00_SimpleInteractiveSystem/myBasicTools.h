//
// Instructor: Sai-Keung WONG
// Email:	cswingo@cs.nctu.edu.tw
//			wingo.wong@gmail.com
//
// National Yang Ming Chiao Tung University, Taiwan
// Computer Science
// Date: 2021/03/29
//
#ifndef __MY_BASIC_TOOLS_H_
#define __MY_BASIC_TOOLS_H_

extern double getRandDouble(double x0, double x1);
//extern int getRandInt(int x0, int x1);
#endif