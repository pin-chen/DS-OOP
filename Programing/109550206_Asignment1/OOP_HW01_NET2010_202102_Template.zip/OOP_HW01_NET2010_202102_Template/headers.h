#ifndef __HEADERS_H__
#define __HEADERS_H__
#include <windows.h>
#include <time.h>
#include <math.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <GL/freeglut_ext.h>

#endif